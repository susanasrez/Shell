//Improtación de librerías 
#include <string.h>
#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h>
#include <ctype.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
int n;

//Variables constantes
#define MAX_LINE_LENGTH 1024		//Máximo de línea
#define SPACE_CHARS " \t\n\r"		//Espacios
#define MAX_ARGS 128			//Máximo de argumentos
#define RUTA 105			//máximo de ruta
#define BCYAN "\033[1;036m"		//Color Cyan
#define BBLU "\e[1;34m"			//Color azul
#define RESET "\033[0m"			//Color actual

//Función que separa los comandos por palabras.
bool parse_command(char* command,char* argv[],size_t max_args){
  	if(!argv || !max_args){				//Si faltan los argumentos, no hace nada
		return false; }
  
  	size_t i=0;

  	char* palabra=strtok(command,SPACE_CHARS);	//Parte en subcadenas 
  	while(palabra!=NULL)
  	{
    		if(i == max_args-1) 			//Se extiende del límite
    			{ argv[i]=NULL; 
			return false; }			//No se realiza

    		argv[i] = palabra;			//Guarda por argumentos
		i++;
    		palabra=strtok(NULL,SPACE_CHARS);
		n++; //partir una cadena en subcadenas usando como separador los caracteres que queramos
  	}
  
  	argv[i]=NULL;					//Último argumento = NULL
  	return true;
}


//Función que transforma a minúsculas
void minusculas(char* str){
	while (*str != '\0'){				//Recorre hasta el final
		*str = tolower(*str);			//Cambia un caracter a minúsculas
		str++;
	}
}

int main()
{

//Declaración de las variables
	char input_line[MAX_LINE_LENGTH];	//Contenedor donde se guardan los argumentos
	char* args[MAX_ARGS];			//Contenedor donde se guardan los agumentos separados
	char PWD[RUTA];				//Contenedor donde se guarda la ruta
	
//Bucle de ejecución
  while(true)					
  {
	getcwd(PWD,RUTA); 			//Obteniendo la ruta actual y cargando en PWD
	printf(BCYAN);				//Impresión del color
	printf("%s > ",PWD);			//Impresión de la ruta
	printf(RESET);				//Reestablecer el color

	n = 0;					//Contador de palabras
    	if(fgets(input_line,MAX_LINE_LENGTH,stdin)!=NULL){	//Captura la linea de la consola
		if(parse_command(input_line,args,MAX_ARGS)){	
//Condiciones
			minusculas(args[0]);			//Conversión del primer argumento a minúsculas		
        		if(strcmp(args[0],"exit")==0) {			//Exit = termina el programa
				printf(BBLU);	
        			printf("Terminando el shell...\n"); 
				printf(RESET);
				return false; }
			else if(strcmp(args[0],"quit")==0) {		//Quit = termina el programa
				printf(BBLU);	
        			printf("Terminando el shell...\n"); 
				printf(RESET);
				return false; }
			else if(strcmp(args[0],"cd")==0) {		//Cd
				if (args[1]){				//Si existe dirtectorio
					if(chdir(args[1])!= 0){		//Ejecuta
						printf(BBLU);	
						printf("No existe el directorio o no se pudo cambiar\n");
						printf(RESET);
					}
				}
			}
//Ejecución de los comandos
			else{
				pid_t child_pid;			//Variable del pid del hijo
				switch(child_pid=fork()){		//Creación de un hijo = fork()
					case -1:{//Caso de error
						printf("Error!No se pudo crear un proceso hijo\n");
						break;
     					}
					case 0:{ //proceso hijo
						if (strcmp(args[n-1],"&")==0){		//Comprueba que el último es un &
							args[n-1] = NULL;		//Elimina el &
						}	
						int ejecutar;
						ejecutar = execvp(input_line, args);	//Ejecución
						if (ejecutar){				//Comando erróneo
							printf(BBLU);	
							printf("Error! Comando no encontrado\n");
							printf(RESET);
							exit(1);}
	  				}
					default: //proceso padre
					{
						if (strcmp(args[n-1],"&")==0){						//Ejecución con el &
							printf(BBLU);	
							printf("Pid del proceso que se genera: %d\n", child_pid);	//Impresión del pid hijo
							printf(RESET);
						}
						else{									//Ejecución normal
							int status;
							pid_t wait_pid;						//Pid de espera				
        						if((wait_pid=waitpid(child_pid, &status, 0))==-1){		//Espera la finalizaión del hijo
								printf(BBLU);	
          							printf("Error en el proceso padre\n");
								printf(RESET);
          							break;
        						}
						}

					}
				}
			}
            		
     		}
  	 }
  }
  return EXIT_SUCCESS;
}

